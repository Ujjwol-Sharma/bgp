/**
 * BPG Academy — Serverless Email OTP Dispatcher (api/send-email-otp.js)
 * Compatible with Vercel Serverless Functions & Local Node/Express (localhost:3000)
 * Sends a 6-digit verification OTP via Resend API (https://resend.com) with HMAC token signing.
 */

const crypto = require('crypto');

const OTP_SECRET = process.env.OTP_SECRET || 'bpg-maths-academy-hmac-secret-2026';
const OTP_TTL_MS = 10 * 60 * 1000; // 10 minutes

if (!global.__BPG_OTP_STORE__) {
    global.__BPG_OTP_STORE__ = new Map();
}

function createSignedOtpToken(email, otp, expiresAt) {
    const payload = `${email.toLowerCase().trim()}|${otp}|${expiresAt}`;
    const signature = crypto
        .createHmac('sha256', OTP_SECRET)
        .update(payload)
        .digest('hex');
    return Buffer.from(JSON.stringify({ email: email.toLowerCase().trim(), expiresAt, signature })).toString('base64url');
}

function escapeHtmlEmail(str) {
    return String(str || '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function buildOtpEmailHtml({ name, email, grade, otp }) {
    const safeName = escapeHtmlEmail(name || 'Scholar');
    const safeEmail = escapeHtmlEmail(email || '');
    const safeGrade = escapeHtmlEmail(grade || 'Class 11');
    const safeOtp = escapeHtmlEmail(otp || '');
    return `
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>BPG Academy Verification Code</title>
    </head>
    <body style="margin:0; padding:32px 16px; background-color:#FAF8F5; font-family:'Inter', -apple-system, BlinkMacSystemFont, sans-serif; color:#1C2430;">
        <div style="max-width:520px; margin:0 auto; background:#FFFFFF; border:1px solid #E8E1D7; border-radius:14px; padding:36px 32px; box-shadow:0 8px 24px rgba(28,36,48,0.06);">
            <div style="font-size:12px; font-weight:700; letter-spacing:0.08em; text-transform:uppercase; color:#1E3A8A; margin-bottom:10px;">
                BPG Academy &bull; NEPAL
            </div>
            <h1 style="font-family:Georgia, serif; font-size:24px; color:#1C2430; margin:0 0 12px;">
                Verify Your Student Account
            </h1>
            <p style="font-size:15px; line-height:1.6; color:#475569; margin:0 0 20px;">
                Namaste <strong>${safeName}</strong>, use the 6-digit verification code below to unlock your <strong>${safeGrade}</strong> portal at BPG Academy.
            </p>
            <div style="background:#F4EFEA; border:1px solid #D6CEC2; border-left:4px solid #1E3A8A; border-radius:10px; padding:20px; text-align:center; margin:24px 0;">
                <div style="font-size:11px; text-transform:uppercase; letter-spacing:0.08em; color:#64748B; margin-bottom:6px;">
                    6-Digit One-Time Passcode (Valid for 10 Minutes)
                </div>
                <div style="font-family:'Courier New', monospace; font-size:34px; font-weight:800; letter-spacing:8px; color:#1E3A8A;">
                    ${safeOtp}
                </div>
            </div>
            <p style="font-size:13px; color:#64748B; line-height:1.6; margin:0 0 20px;">
                <em>&ldquo;Focus on the Concepts Rather Than the Problems.&rdquo;</em><br>
                &mdash; <strong>Bishnu Prasad Gautam (BPG Sir)</strong>, Over 12+ Years of Senior Secondary Academic Leadership (M.Sc. Mathematics, TU Topper)
            </p>
            <hr style="border:none; border-top:1px solid #E8E1D7; margin:20px 0;">
            <div style="font-size:12px; color:#94A3B8;">
                Requested for ${safeEmail}. If you did not request this code, you can safely ignore this email.
            </div>
        </div>
    </body>
    </html>
    `;
}

module.exports = async function handler(req, res) {
    // Enable CORS
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

    if (req.method === 'OPTIONS') {
        return res.status(200).end();
    }

    if (req.method !== 'POST') {
        return res.status(405).json({ ok: false, error: 'Method Not Allowed. Use POST.' });
    }

    try {
        const body = typeof req.body === 'string' ? JSON.parse(req.body || '{}') : (req.body || {});
        const email = String(body.email || '').trim().toLowerCase();
        const name = String(body.name || 'Student').trim();
        const grade = String(body.grade || 'Class 11').trim();

        if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            return res.status(400).json({ ok: false, error: 'Please provide a valid email address.' });
        }

        // Generate 6-digit OTP
        const otp = String(crypto.randomInt(100000, 1000000));
        const expiresAt = Date.now() + OTP_TTL_MS;
        const otpToken = createSignedOtpToken(email, otp, expiresAt);

        // Save in memory store for same-instance verification
        global.__BPG_OTP_STORE__.set(email, {
            otp,
            name,
            grade,
            expiresAt,
            attempts: 0
        });

        const resendApiKey = process.env.RESEND_API_KEY;
        const fromAddress = process.env.RESEND_FROM_EMAIL || 'BPG Academy <onboarding@resend.dev>';

        if (resendApiKey) {
            const response = await fetch('https://api.resend.com/emails', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${resendApiKey}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    from: fromAddress,
                    to: [email],
                    subject: `${otp} is your BPG Academy Verification Code`,
                    html: buildOtpEmailHtml({ name, email, grade, otp })
                })
            });

            const result = await response.json();
            if (response.ok) {
                return res.status(200).json({
                    ok: true,
                    provider: 'resend',
                    email,
                    expiresAt,
                    otpToken,
                    message: `A 6-digit verification code has been emailed to ${email}.`
                });
            } else {
                console.warn('[BPG OTP] Resend API warning, falling back to preview mode:', result);
            }
        }

        // Localhost / Sandbox Fallback (when RESEND_API_KEY is not set or restricted to verified domain)
        console.log(`\n============================================================`);
        console.log(`[BPG Academy — EMAIL OTP DISPATCHED]`);
        console.log(`Student : ${name} (${grade})`);
        console.log(`Email   : ${email}`);
        console.log(`6-Digit : ${otp} (Valid for 10 minutes)`);
        console.log(`============================================================\n`);

        return res.status(200).json({
            ok: true,
            provider: 'local_preview',
            email,
            expiresAt,
            otpToken,
            demoOtp: otp,
            message: `6-digit verification code generated for ${email}.`
        });
    } catch (err) {
        console.error('[BPG OTP Error]:', err);
        return res.status(500).json({
            ok: false,
            error: 'Could not dispatch verification code. Please try again.'
        });
    }
};
