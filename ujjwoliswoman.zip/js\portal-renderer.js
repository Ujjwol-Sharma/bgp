/* BPG Academy — Dedicated Single-Class Portal Renderer (js/portal-renderer.js) */

/* --------------------------------------------------------------------------
   1. STUDENT PORTAL RENDERER (CLASS 10, CLASS 11, CLASS 12 & AFTER 12)
   -------------------------------------------------------------------------- */
function renderEntireStudentPortal() {
    const heroImg = document.getElementById('heroPortraitImg');
    if (heroImg && ACADEMY_STATE.faculty?.portraitUrl) {
        heroImg.src = ACADEMY_STATE.faculty.portraitUrl;
    }

    document.querySelectorAll('[data-field]').forEach(el => {
        const path = el.getAttribute('data-field');
        const val = getByPath(ACADEMY_STATE, path);
        if (val !== undefined && val !== '') {
            el.innerHTML = val;
        }
    });

    renderAnnouncementsDrawer();

    const shortMap = {
        'class-10': 'c10',
        'class-11': 'c11',
        'class-12': 'c12',
        'after-12': 'entrance'
    };

    ['class-10', 'class-11', 'class-12', 'after-12'].forEach(classKey => {
        const pData = ACADEMY_STATE.portals?.[classKey];
        if (!pData) return;
        const totals = computeSyllabusTotals(pData.syllabusRows);
        const shortPrefix = shortMap[classKey] || 'c11';

        // Dynamic Sync: Homepage Program Cards
        const homeThumb = document.getElementById(`homeCardThumb-${classKey}`);
        if (homeThumb && pData.thumbUrl) homeThumb.src = pData.thumbUrl;
        const homeTitle = document.getElementById(`homeCardTitle-${classKey}`);
        if (homeTitle && pData.gradeTitle) homeTitle.textContent = pData.gradeTitle;
        const homeDesc = document.getElementById(`homeCardDesc-${classKey}`);
        if (homeDesc && pData.description) homeDesc.textContent = pData.description;

        // Dynamic Sync: Course Workspace Hero Banner
        const heroThumb = document.getElementById(`heroThumb-${classKey}`);
        if (heroThumb && pData.thumbUrl) heroThumb.src = pData.thumbUrl;
        const heroTitle = document.getElementById(`heroTitle-${classKey}`);
        if (heroTitle && pData.gradeTitle) heroTitle.textContent = pData.gradeTitle;
        const heroDesc = document.getElementById(`heroDesc-${classKey}`);
        if (heroDesc && pData.description) heroDesc.textContent = pData.description;
        const heroLessons = document.getElementById(`heroLessons-${classKey}`);
        if (heroLessons && pData.metaLessons) heroLessons.innerHTML = `<i class="fa-solid fa-video"></i> ${escapeHtml(pData.metaLessons)}`;
        const heroNotes = document.getElementById(`heroNotes-${classKey}`);
        if (heroNotes && pData.metaNotes) heroNotes.innerHTML = `<i class="fa-solid fa-file-pdf"></i> ${escapeHtml(pData.metaNotes)}`;
        const heroLive = document.getElementById(`heroLive-${classKey}`);
        if (heroLive && pData.metaLive) heroLive.innerHTML = `<i class="fa-solid fa-tower-broadcast"></i> ${escapeHtml(pData.metaLive)}`;

        // TAB 1: SYLLABUS BLUEPRINT SPECIFICATION GRID
        const sylBox = document.getElementById(`syllabusContainer-${classKey}`);
        if (sylBox) {
            sylBox.innerHTML = `
                <div class="syllabus-card-wrap">
                    <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px; margin-bottom:14px;">
                        <div>
                            <span class="calm-unit-pill">${pData.curriculumHeader || 'Official Specification Grid'}</span>
                            <h3 style="font-size:1.3rem; margin-top:6px;">${pData.gradeTitle}</h3>
                        </div>
                        <button class="btn-calm-secondary sm" onclick="switchClassTab('${shortPrefix}', 'units', document.getElementById('tab-${shortPrefix}-units'))">
                            <span>Open Units &amp; Theory</span> <i class="fa-solid fa-arrow-right"></i>
                        </button>
                    </div>
                    <div style="overflow-x:auto;">
                        <table class="syllabus-table">
                            <thead>
                                <tr>
                                    <th>Unit Code</th>
                                    <th>Unit / Domain</th>
                                    <th>Teaching Hours</th>
                                    <th>Board / Exam Marks</th>
                                    <th>Exam Weightage Pattern</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${(pData.syllabusRows || []).map(r => `
                                    <tr>
                                        <td><strong style="color:var(--accent-navy);">${r.code}</strong></td>
                                        <td><strong style="color:var(--text-primary);">${r.name || r.domain || ''}</strong></td>
                                        <td><span>${r.hours}</span></td>
                                        <td><span class="calm-unit-pill">${r.marks}</span></td>
                                        <td><span>${r.focus || r.weightage || ''}</span></td>
                                    </tr>
                                `).join('')}
                            </tbody>
                            <tfoot>
                                <tr class="syllabus-tfoot-row">
                                    <td colspan="2">Total Official Curriculum Blueprint (${(pData.syllabusRows || []).length} Domains)</td>
                                    <td>${totals.totalHours} hrs</td>
                                    <td><span class="calm-unit-pill">${totals.totalMarks} Marks</span></td>
                                    <td>${classKey === 'after-12' ? 'IOE Pulchowk CBT (-0.25 Negative Marking)' : 'NEB CDC Board Specification'}</td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            `;
        }

        // TAB 2: UNITS & THEORY SIDEBAR + KATEX READER
        renderUnitsTree(classKey, '');
        const activeId = currentActiveTopic[classKey] || pData.units[0]?.topics[0]?.id;
        if (activeId) {
            selectDeepSubtopic(classKey, activeId);
        }

        // TAB 3: LIVE CLASS CALENDAR
        renderPortalCalendar(classKey);

        // TAB 4: NOTES & PDFS (Strict Single-Class: All resources 100% accessible)
        const notesBox = document.getElementById(`notesContainer-${classKey}`);
        if (notesBox) {
            const activeNotes = getNormalizedPortalNotes(classKey);
            notesBox.innerHTML = `
                <div class="notes-vault-grid">
                    ${activeNotes.map((n, nIdx) => `
                        <div class="note-pdf-card">
                            <div class="note-pdf-left">
                                <div class="pdf-icon-box"><i class="fa-regular fa-file-pdf"></i></div>
                                <div>
                                    <span class="note-badge-pill free">Class Resource &bull; Unlocked</span>
                                    <h4 style="font-size:0.98rem; margin-bottom:2px;">${n.title}</h4>
                                    <small style="color:var(--text-tertiary);">
                                        <span>${n.unit}</span> &bull;
                                        <span>${n.pages}</span> &bull;
                                        <span>${n.fileSize || '2.5 MB'}</span>
                                    </small>
                                </div>
                            </div>
                            <div style="display:flex; align-items:center; gap:8px; flex-wrap:wrap;">
                                <button class="btn-calm-secondary sm" onclick="openPdfViewerModal(${nIdx}, '${classKey}')">
                                    <i class="fa-regular fa-eye"></i> <span>View in App</span>
                                </button>
                                <button class="btn-calm-secondary sm" onclick="downloadNoteFormulaSheet(${nIdx}, '${classKey}')" title="Download Resource">
                                    <i class="fa-solid fa-download"></i> <span>Download</span>
                                </button>
                            </div>
                        </div>
                    `).join('')}
                </div>
            `;
        }
    });

    // Auto-render KaTeX math formulas
    if (window.renderMathInElement) {
        renderMathInElement(document.body, {
            delimiters: [
                { left: '$$', right: '$$', display: true },
                { left: '$', right: '$', display: false }
            ],
            throwOnError: false
        });
    }
}

/* --------------------------------------------------------------------------
   2. MASTER-DETAIL UNITS & THEORY READER
   -------------------------------------------------------------------------- */
function renderUnitsTree(classKey, filterQuery) {
    const sidebar = document.getElementById(`readerSidebar-${classKey}`);
    if (!sidebar) return;

    const q = (filterQuery || '').trim().toLowerCase();
    const units = ACADEMY_STATE.portals[classKey]?.units || [];

    sidebar.innerHTML = units.map((u, uIdx) => {
        const matched = (u.topics || []).filter(t => {
            if (!q) return true;
            const hay = [t.title, u.title, t.overview, t.content, t.definitions].filter(Boolean).join(' ').toLowerCase();
            return hay.includes(q);
        });
        if (q && matched.length === 0) return '';

        return `
            <div class="unit-tree-group ${uIdx === 0 || q ? 'open' : ''}">
                <button class="unit-tree-header" onclick="this.parentElement.classList.toggle('open')">
                    <div>
                        <span class="unit-tree-code">${u.code || ''}</span>
                        <span>${u.title || ''}</span>
                    </div>
                    <span style="font-size:0.72rem; color:var(--text-tertiary);">${u.marks || ''}</span>
                </button>
                <div class="unit-subtopics-list">
                    ${matched.map(t => `
                        <button class="subtopic-item-btn ${currentActiveTopic[classKey] === t.id ? 'active' : ''}" id="btn-${t.id}" onclick="selectDeepSubtopic('${classKey}', '${t.id}')">
                            <span class="subtopic-item-title">${t.title || 'Untitled Topic'}</span>
                            <div class="subtopic-item-meta">
                                <span>${t.readTime || '14 min'}</span>
                                <span>${t.badge || 'Board Core'}</span>
                            </div>
                        </button>
                    `).join('')}
                </div>
            </div>
        `;
    }).join('');
}

function selectDeepSubtopic(classKey, topicId) {
    const units = ACADEMY_STATE.portals[classKey]?.units || [];
    let foundUnit = null, foundTopic = null;

    for (let i = 0; i < units.length; i++) {
        const j = (units[i].topics || []).findIndex(item => item.id === topicId);
        if (j !== -1) {
            foundUnit = units[i];
            foundTopic = units[i].topics[j];
            break;
        }
    }
    if (!foundTopic && units[0]?.topics?.[0]) {
        foundUnit = units[0];
        foundTopic = units[0].topics[0];
    }
    if (!foundTopic) return;

    currentActiveTopic[classKey] = foundTopic.id;

    const sidebar = document.getElementById(`readerSidebar-${classKey}`);
    sidebar?.querySelectorAll('.subtopic-item-btn').forEach(b => b.classList.remove('active'));
    document.getElementById(`btn-${foundTopic.id}`)?.classList.add('active');

    const canvas = document.getElementById(`readerCanvas-${classKey}`);
    if (!canvas) return;

    const hasStructuredFields = Boolean(foundTopic.overview || foundTopic.definitions || foundTopic.derivation || foundTopic.example || foundTopic.pitfalls);
    const diagramBlock = foundTopic.diagramUrl
        ? `<div class="reader-section-block" style="text-align:center; margin:18px 0;">
               <img src="${foundTopic.diagramUrl}" alt="${escapeHtml(foundTopic.title || 'Mathematical Diagram')}" style="max-width:100%; max-height:360px; border-radius:10px; border:1px solid var(--border-soft); margin:0 auto;">
           </div>`
        : '';

    const proseHtml = hasStructuredFields ? `
        <div class="textbook-prose">
            ${diagramBlock}
            ${foundTopic.overview ? `
            <div class="reader-section-block">
                <h3>1. Conceptual Overview &amp; Intuition</h3>
                <p>${formatRichMarkdown(foundTopic.overview)}</p>
            </div>` : ''}

            ${foundTopic.definitions ? `
            <div class="reader-section-block">
                <h3>2. Formal Mathematical Definitions &amp; Formulas</h3>
                <div class="math-theorem-box">
                    ${foundTopic.definitions}
                </div>
            </div>` : ''}

            ${foundTopic.derivation ? `
            <div class="reader-section-block">
                <h3>3. Step-by-Step Proof &amp; Analytical Derivation</h3>
                <div class="derivation-step-flow">
                    ${formatRichMarkdown(foundTopic.derivation)}
                </div>
            </div>` : ''}

            ${foundTopic.example ? `
            <div class="reader-section-block">
                <h3>4. High-Yield Solved Examination Problem</h3>
                <div class="example-box">
                    ${formatRichMarkdown(foundTopic.example)}
                </div>
            </div>` : ''}

            ${foundTopic.pitfalls ? `
            <div class="callout-trap red-pen-alert">
                <strong><i class="fa-solid fa-pen-fancy"></i> Signature Red-Pen Examiner Trap:</strong>
                <p style="margin-top:4px;">${formatRichMarkdown(foundTopic.pitfalls)}</p>
            </div>` : ''}
        </div>
    ` : `
        <div class="textbook-prose">
            ${diagramBlock}
            <div class="reader-section-block">
                ${formatRichMarkdown(foundTopic.content || '')}
            </div>
        </div>
    `;

    canvas.innerHTML = `
        <article class="deep-topic-article">
            <header class="deep-topic-header">
                <span class="unit-code-badge">${foundUnit?.code || 'Unit'}: ${foundUnit?.title || ''}</span>
                <h2>${foundTopic.title}</h2>
                <div class="deep-topic-meta">
                    <span><i class="fa-regular fa-clock"></i> ${foundTopic.readTime || '14 min read'}</span>
                    <span><i class="fa-solid fa-award"></i> ${foundUnit?.marks || 'Board Core'}</span>
                    <span><i class="fa-solid fa-shield-halved"></i> Verified CDC / NEB Curriculum</span>
                </div>
            </header>
            <div class="deep-topic-body" id="topicBodyContent">
                ${proseHtml}
            </div>
        </article>
    `;

    renderMathSafely(canvas);
}

/* --------------------------------------------------------------------------
   3. LIVE CLASS CALENDAR RENDERER
   -------------------------------------------------------------------------- */
function renderPortalCalendar(classKey) {
    const calMount = document.getElementById(`calendarContainer-${classKey}`);
    if (!calMount) return;

    const allEvents = Array.isArray(ACADEMY_STATE.calendarEvents)
        ? ACADEMY_STATE.calendarEvents
        : DEFAULT_PUBLIC_DATA.calendarEvents;
    const events = allEvents.filter(ev => ev.portal === classKey || ev.portal === 'all');

    calMount.innerHTML = `
        <div class="calendar-card-wrap">
            <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px; margin-bottom:16px;">
                <div>
                    <h3 style="font-size:1.25rem; font-weight:700; color:var(--text-primary); margin:0;">Live Zoom Interactive Classes</h3>
                    <p style="font-size:0.85rem; color:var(--text-secondary); margin-top:3px;">
                        Interactive problem-solving, live proof evaluations, and doubt resolution with BPG Sir.
                    </p>
                </div>
            </div>

            <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(320px, 1fr)); gap:16px;">
                ${events.map(ev => `
                    <div style="background:var(--bg-card); border:1.5px solid var(--border-soft); border-radius:12px; padding:20px; display:flex; flex-direction:column; justify-content:space-between; gap:14px; box-shadow:0 2px 8px rgba(0,0,0,0.03);">
                        <div>
                            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
                                <span style="font-size:0.75rem; font-weight:700; padding:4px 10px; border-radius:999px; background:var(--brand-primary-soft, #EEF2FF); color:var(--brand-primary, #1E3A8A); text-transform:uppercase;">
                                    Live Zoom Session
                                </span>
                                <span style="font-size:0.82rem; font-weight:600; color:var(--text-tertiary);">${ev.recurrenceLabel || 'Weekly'}</span>
                            </div>
                            <h4 style="font-size:1.1rem; font-weight:700; color:var(--text-primary); margin-bottom:8px;">${ev.title}</h4>
                            <div style="font-size:0.85rem; color:var(--text-secondary); display:flex; flex-direction:column; gap:6px;">
                                <span><i class="fa-regular fa-clock" style="color:var(--brand-primary);"></i> <strong>Timing:</strong> ${ev.timings || '06:30 AM – 07:45 AM NPT'}</span>
                                <span><i class="fa-solid fa-video" style="color:var(--brand-primary);"></i> <strong>Meeting ID:</strong> <code>${ev.meetingId}</code> &bull; <strong>Passcode:</strong> <code>${ev.passcode}</code></span>
                                ${ev.syllabus ? `<p style="margin-top:6px; font-size:0.82rem; color:var(--text-tertiary); line-height:1.5;">${ev.syllabus}</p>` : ''}
                            </div>
                        </div>

                        <div style="display:flex; gap:10px; border-top:1px solid var(--border-soft); padding-top:14px; margin-top:4px;">
                            <a href="${ev.zoomUrl}" target="_blank" rel="noopener" class="btn btn-primary" style="flex:1; justify-content:center; text-decoration:none; padding:10px 16px; font-size:0.88rem;">
                                <i class="fa-solid fa-video" style="margin-right:6px;"></i> Launch Zoom
                            </a>
                            <button type="button" class="btn btn-secondary" onclick="downloadSampleIcs('${ev.title}', '${ev.timings}')" title="Add to Calendar (.ics)" style="padding:10px 14px; font-size:0.88rem;">
                                <i class="fa-solid fa-calendar-plus"></i>
                            </button>
                        </div>
                    </div>
                `).join('')}
            </div>
        </div>
    `;
}

/* --------------------------------------------------------------------------
   4. IN-APP PDF VIEWER & FORMULA SHEET GENERATOR
   -------------------------------------------------------------------------- */
function generateFormulaSheetBlobUrl(note, classKey) {
    const pData = ACADEMY_STATE.portals[classKey];
    const unitsSummary = (pData?.units || []).map(u => {
        const topDesc = (u.topics || []).map(t => `  * ${t.title}`).join('\n');
        return `[${u.code}: ${u.title}] (${u.marks})\n${topDesc}`;
    }).join('\n\n');

    const content = `============================================================
BPG ACADEMY — OFFICIAL STUDY HANDOUT & FORMULA SHEET
Faculty Lead: Bishnu Prasad Gautam (BPG Sir)
Postgraduate Distinction, Central Department of Mathematics, TU
============================================================

Title: ${note.title}
Program: ${pData?.gradeTitle || 'BPG Academy'}
Scope: ${note.unit} | ${note.pages} | ${note.fileSize || '2.5 MB'}
Core Motto: "Focus on the Concepts Rather Than the Problems."

------------------------------------------------------------
OFFICIAL SPECIFICATIONS & THEOREMS:
${unitsSummary}
============================================================
© 2026 BPG Academy. All Rights Reserved.
`;
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    return URL.createObjectURL(blob);
}

function openPdfViewerModal(nIdx, classKey) {
    const notes = getNormalizedPortalNotes(classKey);
    const note = notes[nIdx];
    if (!note) return;
    const pData = ACADEMY_STATE.portals[classKey];

    document.getElementById('pdfModalBadge').textContent = 'Verified Resource';
    document.getElementById('pdfModalTitle').textContent = note.title;
    document.getElementById('pdfModalMeta').textContent = `${note.unit} • ${note.pages} • ${note.fileSize || '2.5 MB'} • Prepared by Bishnu Prasad Gautam (BPG Sir)`;

    const bodyEl = document.getElementById('pdfModalBody');
    if (note.fileUrl && note.fileUrl !== '#' && (note.fileUrl.startsWith('data:application/pdf') || note.fileUrl.startsWith('http') || note.fileUrl.endsWith('.pdf'))) {
        bodyEl.innerHTML = `<iframe src="${note.fileUrl}" style="width:100%; height:440px; border:none; border-radius:8px;"></iframe>`;
    } else {
        const sampleTopics = (pData?.units || []).slice(0, 3).map(u => {
            const firstT = u.topics?.[0];
            return firstT ? `
                <div style="margin-bottom:18px; padding-bottom:14px; border-bottom:1px solid var(--border-soft);">
                    <strong style="color:var(--accent-navy); font-size:0.84rem;">${u.code || ''}: ${u.title || ''} (${u.marks || ''})</strong>
                    <h4 style="margin:4px 0 8px; font-size:1.02rem;">${firstT.title || ''}</h4>
                    <div class="math-theorem-box" style="margin:8px 0; padding:12px 16px;">${firstT.definitions || formatRichMarkdown(firstT.content || '')}</div>
                    ${firstT.pitfalls ? `<p style="font-size:0.88rem; color:var(--text-secondary); margin:6px 0;"><strong>Red-Pen Examiner Alert:</strong> ${firstT.pitfalls}</p>` : ''}
                </div>
            ` : '';
        }).join('');

        bodyEl.innerHTML = `
            <div style="margin-bottom:14px; padding:12px 16px; background:var(--bg-elevated); border-radius:8px; border-left:3px solid var(--accent-navy);">
                <strong>BPG Academy — In-App Resource &amp; Formula Preview</strong>
                <p style="font-size:0.84rem; color:var(--text-secondary); margin-top:4px;">
                    Review key theorems and Red-Pen notes below, or click <strong>Download Note / Formula Sheet</strong> to save an offline copy.
                </p>
            </div>
            ${sampleTopics}
        `;
        renderMathSafely(bodyEl);
    }

    const dlBtn = document.getElementById('pdfModalDownloadBtn');
    if (dlBtn) {
        dlBtn.href = generateFormulaSheetBlobUrl(note, classKey);
        const safeName = note.title.toLowerCase().replace(/[^a-z0-9]+/g, '-') + (note.fileUrl ? '.pdf' : '-formula-sheet.txt');
        dlBtn.setAttribute('download', safeName);
    }

    document.getElementById('pdfViewerModal')?.classList.add('open');
}

function closePdfViewerModal() {
    document.getElementById('pdfViewerModal')?.classList.remove('open');
}

function downloadNoteFormulaSheet(nIdx, classKey) {
    const notes = getNormalizedPortalNotes(classKey);
    const note = notes[nIdx];
    if (!note) return;
    const url = generateFormulaSheetBlobUrl(note, classKey);
    const a = document.createElement('a');
    a.href = url;
    a.download = note.title.toLowerCase().replace(/[^a-z0-9]+/g, '-') + (note.fileUrl ? '.pdf' : '-formula-sheet.txt');
    document.body.appendChild(a);
    a.click();
    a.remove();
    showToast(`Downloading "${note.title}"...`);
}

/* --------------------------------------------------------------------------
   5. NOTIFICATIONS & TOASTS
   -------------------------------------------------------------------------- */
function renderAnnouncementsDrawer() {
    const listMount = document.getElementById('notifList');
    if (!listMount) return;

    const announcements = ACADEMY_STATE.announcements || DEFAULT_PUBLIC_DATA.announcements;
    listMount.innerHTML = announcements.map(a => `
        <div class="notif-item ${a.unread ? 'unread' : ''}">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
                <span class="notif-tag">${a.tag}</span>
                <span style="font-size:0.75rem; color:var(--text-tertiary);">${a.time}</span>
            </div>
            <strong>${a.title}</strong>
            <p>${a.body}</p>
        </div>
    `).join('');
}

function toggleNotifDrawer(e) {
    if (e) e.stopPropagation();
    document.getElementById('notifDrawer')?.classList.toggle('open');
}

function markAllNotificationsRead() {
    document.querySelectorAll('.notif-item').forEach(item => item.classList.remove('unread'));
    const dot = document.getElementById('notifUnreadDot');
    if (dot) dot.style.display = 'none';
    const badge = document.getElementById('notifUnreadBadge');
    if (badge) badge.style.display = 'none';
    showToast('All notifications marked as read.');
}

function showToast(message) {
    const container = document.getElementById('toastContainer');
    if (!container) return;
    const toast = document.createElement('div');
    toast.className = 'toast-msg';
    toast.textContent = message;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 3500);
}

function escapeHtml(str) {
    return String(str || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
