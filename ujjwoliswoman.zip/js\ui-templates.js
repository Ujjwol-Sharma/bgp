/* ==========================================================================
   BPG ACADEMY — MODULAR UI TEMPLATES MOUNTER (js/ui-templates.js)
   Strict Single-Class Dedicated Architecture:
   - Exactly 4 Dedicated Tabs per workspace (Syllabus, Units, Calendar, Notes)
   - Mandatory Single-Class Registration Wall
   - Restricted Access Modal for cross-program gating
   - PDF Viewer & Live Zoom Session modals
   ========================================================================== */

(function mountBpgModularTemplates() {
    const workspacesMount = document.getElementById('bpgWorkspacesMount');
    if (workspacesMount) {
        workspacesMount.outerHTML = `
    <!-- ==========================================================================
         VIEW 2: CLASS 10 (SEE) WORKSPACE (#view-c10) — 4 DEDICATED TABS
         ========================================================================== -->
    <main class="view-container portal-view" id="view-c10" style="display:none;">
        <div class="container">
            <!-- Workspace Navigation Bar with Back Button -->
            <div class="workspace-top-bar" style="display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:12px; margin-bottom:16px;">
                <button type="button" class="btn-back" onclick="handleHomeClick()">← Back to Dashboard</button>
                <div class="breadcrumb-nav">
                    <a href="#home" onclick="handleHomeClick(); return false;">Home</a>
                    <span>/</span>
                    <span>Class Portals</span>
                    <span>/</span>
                    <span>Class 10 (SEE Mathematics Foundation)</span>
                </div>
            </div>

            <!-- Course Overview Hero -->
            <div class="course-workspace-hero">
                <div class="course-detail-thumbnail">
                    <img src="images/thumb_c10.jpg" id="heroThumb-class-10" alt="Class 10 SEE Mathematics Thumbnail">
                </div>
                <div class="course-hero-content">
                    <h1 id="heroTitle-class-10">Class 10 (SEE Mathematics Foundation)</h1>
                    <p id="heroDesc-class-10">
                        A complete Class 10 Compulsory &amp; Optional Mathematics preparation course. Comprehensive geometric circle theorem step-proofs, unseen rider derivations, coordinate geometry, matrices, trigonometry, and model question sets.
                    </p>
                    <div class="course-meta-pills-row">
                        <span class="course-meta-pill" id="heroLessons-class-10"><i class="fa-solid fa-video"></i> 2 lessons</span>
                        <span class="course-meta-pill" id="heroNotes-class-10"><i class="fa-solid fa-file-pdf"></i> 6 notes</span>
                        <span class="course-meta-pill" id="heroLive-class-10"><i class="fa-solid fa-tower-broadcast"></i> Sunday Live Batch</span>
                    </div>
                </div>
            </div>

            <!-- Class-Specific 4-Tab Taskbar (Access Plans Tab Completely Removed) -->
            <div class="understated-tab-strip" role="tablist" aria-label="Class 10 Sub-Taskbar">
                <button class="strip-tab-btn active" id="tab-c10-syllabus" onclick="switchClassTab('c10', 'syllabus', this)">
                    <i class="fa-solid fa-table-list"></i> 1. Syllabus Blueprint
                </button>
                <button class="strip-tab-btn" id="tab-c10-units" onclick="switchClassTab('c10', 'units', this)">
                    <i class="fa-solid fa-book-open-reader"></i> 2. Units &amp; Theory
                </button>
                <button class="strip-tab-btn" id="tab-c10-live" onclick="switchClassTab('c10', 'live', this)">
                    <i class="fa-regular fa-calendar-check"></i> 3. Live Class Calendar
                </button>
                <button class="strip-tab-btn" id="tab-c10-notes" onclick="switchClassTab('c10', 'notes', this)">
                    <i class="fa-regular fa-file-pdf"></i> 4. Notes &amp; PDFs
                </button>
            </div>

            <!-- Tab Panes Container for Class 10 (Exactly 4 functional panes) -->
            <div id="classContentPanes-c10">
                <div class="portal-tab-pane active" id="pane-c10-syllabus">
                    <div id="syllabusContainer-class-10"></div>
                </div>
                <div class="portal-tab-pane" id="pane-c10-units">
                    <div class="deep-reader-layout">
                        <aside class="reader-sidebar" id="readerSidebar-class-10"></aside>
                        <div class="reader-canvas" id="readerCanvas-class-10"></div>
                    </div>
                </div>
                <div class="portal-tab-pane" id="pane-c10-live">
                    <div id="calendarContainer-class-10"></div>
                </div>
                <div class="portal-tab-pane" id="pane-c10-notes">
                    <div id="notesContainer-class-10"></div>
                </div>
            </div>
        </div>
    </main>

    <!-- ==========================================================================
         VIEW 3: GRADE XI MATHEMATICS WORKSPACE (#view-c11) — 4 DEDICATED TABS
         ========================================================================== -->
    <main class="view-container portal-view" id="view-c11" style="display:none;">
        <div class="container">
            <!-- Workspace Navigation Bar with Back Button -->
            <div class="workspace-top-bar" style="display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:12px; margin-bottom:16px;">
                <button type="button" class="btn-back" onclick="handleHomeClick()">← Back to Dashboard</button>
                <div class="breadcrumb-nav">
                    <a href="#home" onclick="handleHomeClick(); return false;">Home</a>
                    <span>/</span>
                    <span>Class Portals</span>
                    <span>/</span>
                    <span>Grade XI Mathematics</span>
                </div>
            </div>

            <!-- Course Overview Hero -->
            <div class="course-workspace-hero">
                <div class="course-detail-thumbnail">
                    <img src="images/thumb_c11.jpg" id="heroThumb-class-11" alt="Grade XI Mathematics Thumbnail">
                </div>
                <div class="course-hero-content">
                    <h1 id="heroTitle-class-11">Grade XI Mathematics</h1>
                    <p id="heroDesc-class-11">
                        A complete Grade XI Mathematics course designed according to the current NEB curriculum. Provides clear conceptual explanations, step-by-step problem solving, worked examples, practice exercises, and exam-focused preparation.
                    </p>
                    <div class="course-meta-pills-row">
                        <span class="course-meta-pill" id="heroLessons-class-11"><i class="fa-solid fa-video"></i> 2 lessons</span>
                        <span class="course-meta-pill" id="heroNotes-class-11"><i class="fa-solid fa-file-pdf"></i> 6 notes</span>
                        <span class="course-meta-pill" id="heroLive-class-11"><i class="fa-solid fa-tower-broadcast"></i> Weekly Zoom Batch</span>
                    </div>
                </div>
            </div>

            <!-- Class-Specific 4-Tab Taskbar (Access Plans Tab Completely Removed) -->
            <div class="understated-tab-strip" role="tablist" aria-label="Class 11 Sub-Taskbar">
                <button class="strip-tab-btn active" id="tab-c11-syllabus" onclick="switchClassTab('c11', 'syllabus', this)">
                    <i class="fa-solid fa-table-list"></i> 1. Syllabus Blueprint
                </button>
                <button class="strip-tab-btn" id="tab-c11-units" onclick="switchClassTab('c11', 'units', this)">
                    <i class="fa-solid fa-book-open-reader"></i> 2. Units &amp; Theory
                </button>
                <button class="strip-tab-btn" id="tab-c11-live" onclick="switchClassTab('c11', 'live', this)">
                    <i class="fa-regular fa-calendar-check"></i> 3. Live Class Calendar
                </button>
                <button class="strip-tab-btn" id="tab-c11-notes" onclick="switchClassTab('c11', 'notes', this)">
                    <i class="fa-regular fa-file-pdf"></i> 4. Notes &amp; PDFs
                </button>
            </div>

            <!-- Tab Panes Container for Class 11 (Exactly 4 functional panes) -->
            <div id="classContentPanes-c11">
                <div class="portal-tab-pane active" id="pane-c11-syllabus">
                    <div id="syllabusContainer-class-11"></div>
                </div>
                <div class="portal-tab-pane" id="pane-c11-units">
                    <div class="deep-reader-layout">
                        <aside class="reader-sidebar" id="readerSidebar-class-11"></aside>
                        <div class="reader-canvas" id="readerCanvas-class-11"></div>
                    </div>
                </div>
                <div class="portal-tab-pane" id="pane-c11-live">
                    <div id="calendarContainer-class-11"></div>
                </div>
                <div class="portal-tab-pane" id="pane-c11-notes">
                    <div id="notesContainer-class-11"></div>
                </div>
            </div>
        </div>
    </main>

    <!-- ==========================================================================
         VIEW 4: GRADE XII MATHEMATICS WORKSPACE (#view-c12) — 4 DEDICATED TABS
         ========================================================================== -->
    <main class="view-container portal-view" id="view-c12" style="display:none;">
        <div class="container">
            <!-- Workspace Navigation Bar with Back Button -->
            <div class="workspace-top-bar" style="display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:12px; margin-bottom:16px;">
                <button type="button" class="btn-back" onclick="handleHomeClick()">← Back to Dashboard</button>
                <div class="breadcrumb-nav">
                    <a href="#home" onclick="handleHomeClick(); return false;">Home</a>
                    <span>/</span>
                    <span>Class Portals</span>
                    <span>/</span>
                    <span>Grade XII Mathematics</span>
                </div>
            </div>

            <!-- Course Overview Hero -->
            <div class="course-workspace-hero">
                <div class="course-detail-thumbnail">
                    <img src="images/thumb_c12.jpg" id="heroThumb-class-12" alt="Grade XII Mathematics Thumbnail">
                </div>
                <div class="course-hero-content">
                    <h1 id="heroTitle-class-12">Grade XII Mathematics</h1>
                    <p id="heroDesc-class-12">
                        A complete Grade XII Mathematics course designed according to the current NEB curriculum. Provides clear conceptual explanations, step-by-step problem-solving techniques, worked examples, practice exercises, and exam-focused distinction preparation.
                    </p>
                    <div class="course-meta-pills-row">
                        <span class="course-meta-pill" id="heroLessons-class-12"><i class="fa-solid fa-video"></i> 2 lessons</span>
                        <span class="course-meta-pill" id="heroNotes-class-12"><i class="fa-solid fa-file-pdf"></i> 6 notes</span>
                        <span class="course-meta-pill" id="heroLive-class-12"><i class="fa-solid fa-tower-broadcast"></i> Saturday Live Batch</span>
                    </div>
                </div>
            </div>

            <!-- Class-Specific 4-Tab Taskbar (Access Plans Tab Completely Removed) -->
            <div class="understated-tab-strip" role="tablist" aria-label="Class 12 Sub-Taskbar">
                <button class="strip-tab-btn active" id="tab-c12-syllabus" onclick="switchClassTab('c12', 'syllabus', this)">
                    <i class="fa-solid fa-table-list"></i> 1. Syllabus Blueprint
                </button>
                <button class="strip-tab-btn" id="tab-c12-units" onclick="switchClassTab('c12', 'units', this)">
                    <i class="fa-solid fa-book-open-reader"></i> 2. Units &amp; Theory
                </button>
                <button class="strip-tab-btn" id="tab-c12-live" onclick="switchClassTab('c12', 'live', this)">
                    <i class="fa-regular fa-calendar-check"></i> 3. Live Class Calendar
                </button>
                <button class="strip-tab-btn" id="tab-c12-notes" onclick="switchClassTab('c12', 'notes', this)">
                    <i class="fa-regular fa-file-pdf"></i> 4. Notes &amp; PDFs
                </button>
            </div>

            <!-- Tab Panes Container for Class 12 (Exactly 4 functional panes) -->
            <div id="classContentPanes-c12">
                <div class="portal-tab-pane active" id="pane-c12-syllabus">
                    <div id="syllabusContainer-class-12"></div>
                </div>
                <div class="portal-tab-pane" id="pane-c12-units">
                    <div class="deep-reader-layout">
                        <aside class="reader-sidebar" id="readerSidebar-class-12"></aside>
                        <div class="reader-canvas" id="readerCanvas-class-12"></div>
                    </div>
                </div>
                <div class="portal-tab-pane" id="pane-c12-live">
                    <div id="calendarContainer-class-12"></div>
                </div>
                <div class="portal-tab-pane" id="pane-c12-notes">
                    <div id="notesContainer-class-12"></div>
                </div>
            </div>
        </div>
    </main>

    <!-- ==========================================================================
         VIEW 5: AFTER 12 ENTRANCE WORKSPACE (#view-entrance) — 4 DEDICATED TABS
         ========================================================================== -->
    <main class="view-container portal-view" id="view-entrance" style="display:none;">
        <div class="container">
            <!-- Workspace Navigation Bar with Back Button -->
            <div class="workspace-top-bar" style="display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:12px; margin-bottom:16px;">
                <button type="button" class="btn-back" onclick="handleHomeClick()">← Back to Dashboard</button>
                <div class="breadcrumb-nav">
                    <a href="#home" onclick="handleHomeClick(); return false;">Home</a>
                    <span>/</span>
                    <span>Class Portals</span>
                    <span>/</span>
                    <span>After 12 Entrance (IOE / CEE / KU)</span>
                </div>
            </div>

            <!-- Course Overview Hero -->
            <div class="course-workspace-hero">
                <div class="course-detail-thumbnail">
                    <img src="images/thumb_entrance.jpg" id="heroThumb-after-12" alt="After 12 Engineering Entrance Thumbnail">
                </div>
                <div class="course-hero-content">
                    <h1 id="heroTitle-after-12">After 12 Entrance (IOE / CEE / KU Question Bank &amp; Speed Hacks)</h1>
                    <p id="heroDesc-after-12">
                        Complete 50-mark IOE Pulchowk Mathematics engineering entrance preparation with 15-year past question bank, Casio fx-991 calculator speed hacks, option elimination techniques, and CBT model practice sets.
                    </p>
                    <div class="course-meta-pills-row">
                        <span class="course-meta-pill" id="heroLessons-after-12"><i class="fa-solid fa-video"></i> 2 lessons</span>
                        <span class="course-meta-pill" id="heroNotes-after-12"><i class="fa-solid fa-file-pdf"></i> 6 notes</span>
                        <span class="course-meta-pill" id="heroLive-after-12"><i class="fa-solid fa-tower-broadcast"></i> Daily Ranker Batch</span>
                    </div>
                </div>
            </div>

            <!-- Class-Specific 4-Tab Taskbar (Access Plans Tab Completely Removed) -->
            <div class="understated-tab-strip" role="tablist" aria-label="Entrance Sub-Taskbar">
                <button class="strip-tab-btn active" id="tab-entrance-syllabus" onclick="switchClassTab('entrance', 'syllabus', this)">
                    <i class="fa-solid fa-table-list"></i> 1. Syllabus Blueprint
                </button>
                <button class="strip-tab-btn" id="tab-entrance-units" onclick="switchClassTab('entrance', 'units', this)">
                    <i class="fa-solid fa-book-open-reader"></i> 2. Speed Hacks &amp; Theory
                </button>
                <button class="strip-tab-btn" id="tab-entrance-live" onclick="switchClassTab('entrance', 'live', this)">
                    <i class="fa-regular fa-calendar-check"></i> 3. Live Class Calendar
                </button>
                <button class="strip-tab-btn" id="tab-entrance-notes" onclick="switchClassTab('entrance', 'notes', this)">
                    <i class="fa-regular fa-file-pdf"></i> 4. Notes &amp; Past Papers
                </button>
            </div>

            <!-- Tab Panes Container for Entrance (Exactly 4 functional panes) -->
            <div id="classContentPanes-entrance">
                <div class="portal-tab-pane active" id="pane-entrance-syllabus">
                    <div id="syllabusContainer-after-12"></div>
                </div>
                <div class="portal-tab-pane" id="pane-entrance-units">
                    <div class="deep-reader-layout">
                        <aside class="reader-sidebar" id="readerSidebar-after-12"></aside>
                        <div class="reader-canvas" id="readerCanvas-after-12"></div>
                    </div>
                </div>
                <div class="portal-tab-pane" id="pane-entrance-live">
                    <div id="calendarContainer-after-12"></div>
                </div>
                <div class="portal-tab-pane" id="pane-entrance-notes">
                    <div id="notesContainer-after-12"></div>
                </div>
            </div>
        </div>
    </main>
`;
    }

    const modalsMount = document.getElementById('bpgModalsMount');
    if (modalsMount) {
        modalsMount.outerHTML = `
    <!-- ==========================================================================
         DOCKED UTILITIES: WEBSITE GUIDE & MINI SCIENTIFIC CALCULATOR
         ========================================================================== -->
    <div class="floating-dock-container" id="floatingDock">
        <button type="button" id="btnSiteGuide" class="floating-dock-btn" onclick="toggleWebsiteGuide()" title="Open BPG Website Guide">
            <i class="fa-solid fa-comments" aria-hidden="true"></i> <span>Website Guide</span>
        </button>
        <button type="button" id="miniCalcBtn" class="floating-dock-btn calc-btn" onclick="toggleMiniCalculator()" title="Open Mini Scientific Calculator">
            <i class="fa-solid fa-calculator" aria-hidden="true"></i> FX-991 Calc
        </button>
    </div>

    <!-- Floating Messenger-Style Website Guide Window -->
    <div class="site-guide-window" id="siteGuideWindow" role="dialog" aria-labelledby="guideTitle" aria-hidden="true">
        <div class="guide-window-header">
            <div class="guide-header-brand">
                <img src="images/logo.png" alt="BPG Academy logo" class="guide-avatar-img" onerror="this.src='data:image/svg+xml,<svg xmlns=\\'http://www.w3.org/2000/svg\\' viewBox=\\'0 0 40 40\\'><rect width=\\'40\\' height=\\'40\\' rx=\\'20\\' fill=\\'%23111C2D\\'/><text x=\\'20\\' y=\\'25\\' font-family=\\'sans-serif\\' font-size=\\'13\\' font-weight=\\'bold\\' fill=\\'%23D6B979\\' text-anchor=\\'middle\\'>BPG</text></svg>'">
                <div class="guide-header-text">
                    <h3 id="guideTitle">BPG Website Guide</h3>
                    <span class="guide-status-badge"><span class="guide-status-dot"></span> Instant Platform Navigator</span>
                </div>
            </div>
            <div class="guide-header-actions">
                <button type="button" class="guide-ctrl-btn" onclick="toggleWebsiteGuide()" title="Minimize" aria-label="Minimize">—</button>
                <button type="button" class="guide-ctrl-btn" onclick="closeWebsiteGuide()" title="Close" aria-label="Close">✕</button>
            </div>
        </div>

        <!-- Chat Stream Conversation Feed -->
        <div class="guide-chat-stream" id="guideChatStream">
            <div class="guide-msg bot-msg">
                <div class="guide-msg-avatar">
                    <i class="fa-solid fa-graduation-cap"></i>
                </div>
                <div class="guide-msg-content">
                    <p><strong>Namaste!</strong> Welcome to <strong>BPG Academy</strong>. I am your automated Website Guide.</p>
                    <p>How can I assist you today? Tap any question below for immediate textbook-grade guidance, navigation help, or syllabus information.</p>
                </div>
            </div>
        </div>

        <!-- Typing Indicator -->
        <div class="guide-typing-indicator" id="guideTypingIndicator" style="display:none;">
            <span class="typing-dot"></span>
            <span class="typing-dot"></span>
            <span class="typing-dot"></span>
        </div>

        <!-- Quick Reply Rounded Pills Area -->
        <div class="guide-quick-replies-wrap" id="quickReplyWrap">
            <div class="quick-reply-label"><i class="fa-solid fa-bolt"></i> Tap to send.</div>
            <div class="quick-reply-pills-row" id="quickReplyPills">
                <button type="button" class="guide-pill-btn" onclick="askGuideQuestion('how_to_register')">How to register for a class?</button>
                <button type="button" class="guide-pill-btn" onclick="askGuideQuestion('single_class_rule')">How does single-class registration work?</button>
                <button type="button" class="guide-pill-btn" onclick="askGuideQuestion('ioe_past_papers')">Where to find IOE past papers?</button>
                <button type="button" class="guide-pill-btn" onclick="askGuideQuestion('live_zoom')">How to join live Zoom classes?</button>
                <button type="button" class="guide-pill-btn" onclick="askGuideQuestion('who_is_bpg')">Who is BPG Sir?</button>
                <button type="button" class="guide-pill-btn" onclick="askGuideQuestion('classes_offered')">What classes are offered?</button>
                <button type="button" class="guide-pill-btn" onclick="askGuideQuestion('free_notes')">How do I access notes &amp; theory?</button>
                <button type="button" class="guide-pill-btn" onclick="askGuideQuestion('katex_notation')">What is the KaTeX Math notation?</button>
                <button type="button" class="guide-pill-btn" onclick="askGuideQuestion('contact_bpg')">How do I contact BPG Sir directly?</button>
            </div>
        </div>

        <!-- Disabled Bottom Input Area -->
        <div class="guide-input-bar">
            <input type="text" class="guide-input-field" placeholder="Tap questions above for instant guidance..." disabled aria-label="Tap questions above for instant guidance">
            <button type="button" class="guide-send-btn" disabled aria-label="Send"><i class="fa-solid fa-arrow-up"></i></button>
        </div>
    </div>

    <!-- Draggable Mini Scientific Calculator Viewport -->
    <div class="calc-flyout-window" id="calcFlyoutWindow">
        <div class="calc-window-header" id="calcDragHandle">
            <span><i class="fa-solid fa-calculator"></i> Casio FX-991 Mini Solver</span>
            <button class="calc-close-btn" onclick="toggleMiniCalculator()"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <div class="calc-screen-area">
            <div class="calc-history-line" id="calcHistoryLine">DEG</div>
            <div class="calc-lcd-screen" id="calcScreen">0</div>
        </div>
        <div class="calc-keypad-grid">
            <button class="calc-key op" onclick="calcAppend('sin(')">sin</button>
            <button class="calc-key op" onclick="calcAppend('cos(')">cos</button>
            <button class="calc-key op" onclick="calcAppend('tan(')">tan</button>
            <button class="calc-key op" onclick="calcAppend('sqrt(')">√</button>
            <button class="calc-key op" onclick="calcAppend('^')">xʸ</button>

            <button class="calc-key func" onclick="calcClear()">AC</button>
            <button class="calc-key func" onclick="calcBackspace()">DEL</button>
            <button class="calc-key op" onclick="calcAppend('(')">(</button>
            <button class="calc-key op" onclick="calcAppend(')')">)</button>
            <button class="calc-key op" onclick="calcAppend('/')">÷</button>

            <button class="calc-key" onclick="calcAppend('7')">7</button>
            <button class="calc-key" onclick="calcAppend('8')">8</button>
            <button class="calc-key" onclick="calcAppend('9')">9</button>
            <button class="calc-key op" onclick="calcAppend('*')">×</button>
            <button class="calc-key op" onclick="calcAppend('pi')">π</button>

            <button class="calc-key" onclick="calcAppend('4')">4</button>
            <button class="calc-key" onclick="calcAppend('5')">5</button>
            <button class="calc-key" onclick="calcAppend('6')">6</button>
            <button class="calc-key op" onclick="calcAppend('-')">-</button>
            <button class="calc-key op" onclick="calcAppend('e')">e</button>

            <button class="calc-key" onclick="calcAppend('1')">1</button>
            <button class="calc-key" onclick="calcAppend('2')">2</button>
            <button class="calc-key" onclick="calcAppend('3')">3</button>
            <button class="calc-key op" onclick="calcAppend('+')">+</button>
            <button class="calc-key equals" onclick="calcEvaluate()">=</button>

            <button class="calc-key span-two" onclick="calcAppend('0')">0</button>
            <button class="calc-key" onclick="calcAppend('.')">.</button>
            <button class="calc-key op" onclick="calcAppend('ln(')">ln</button>
        </div>
    </div>

    <!-- ==========================================================================
         AUTHENTICATION & STRICT SINGLE-CLASS REGISTRATION MODAL
         ========================================================================== -->
    <div class="modal-backdrop" id="authModal" role="dialog" aria-modal="true">
        <div class="modal-card auth-modal-card">
            <button class="btn-modal-dismiss" onclick="closeAuthModal()"><i class="fa-solid fa-xmark"></i></button>

            <!-- Tab Switcher -->
            <div class="auth-tabs-nav" role="tablist">
                <button type="button" class="auth-tab-btn active" id="authTabSignIn" onclick="switchAuthTab('signin')" role="tab" aria-selected="true">Sign In</button>
                <button type="button" class="auth-tab-btn" id="authTabSignUp" onclick="switchAuthTab('signup')" role="tab" aria-selected="false">Create Account</button>
            </div>

            <!-- PANE 1: SIGN IN -->
            <div id="authSignInContainer" class="auth-pane active">
                <div class="modal-head-tag">Student Sanctuary &bull; Dedicated ID Access</div>
                <h3 class="modal-title">Sign In to Your Workspace</h3>
                <p class="modal-sub">
                    Enter your registered email to immediately mount your dedicated class workspace.
                </p>

                <form onsubmit="handleSignInSubmit(event)">
                    <div class="modal-field">
                        <label for="signinEmail">Registered Email Address</label>
                        <input type="email" id="signinEmail" class="modal-input" placeholder="student@example.com" required>
                    </div>

                    <div class="modal-field">
                        <label for="signinPassword">Access Passkey / PIN</label>
                        <input type="password" id="signinPassword" class="modal-input" placeholder="Enter passkey or PIN" value="bpgstudent">
                    </div>

                    <button type="submit" class="btn-submit-action" id="btnSignInSubmit">
                        <i class="fa-solid fa-arrow-right-to-bracket" style="margin-right:6px;"></i> Sign In to Dedicated Workspace
                    </button>

                    <div style="display:flex; justify-content:space-between; align-items:center; margin-top:14px; font-size:0.82rem;">
                        <button type="button" class="btn-link-action" onclick="quickOtpSignIn()">Sign in via 6-digit OTP</button>
                        <button type="button" class="btn-link-action" onclick="switchAuthTab('signup')" style="color:var(--accent-amber); font-weight:600;">New Student? Register Free →</button>
                    </div>
                </form>
            </div>

            <!-- PANE 2: CREATE ACCOUNT (MANDATORY SINGLE-CLASS SELECTION) -->
            <div id="otpStep1Container" class="auth-pane" style="display:none;">
                <div class="modal-head-tag">Strict Single-Class Enrollment &bull; One ID = One Class</div>
                <h3 class="modal-title">Student Registration</h3>
                <p class="modal-sub">
                    Select your class to unlock your dedicated workspace. Once registered, your student ID is permanently tied to this program.
                </p>

                <form onsubmit="handleRequestEmailOtp(event)">
                    <div class="modal-field">
                        <label for="signupName">Student Full Name</label>
                        <input type="text" id="signupName" class="modal-input" placeholder="e.g. Paribesh Thapa" required>
                    </div>

                    <div class="modal-field">
                        <label for="signupGrade"><strong>Select Your Class (Mandatory &bull; Locked to this ID)</strong></label>
                        <select id="signupGrade" class="modal-input" style="font-weight:600;" required>
                            <option value="Class 12" selected>Class 12 (NEB Mat. 102 &bull; Senior Secondary)</option>
                            <option value="Class 11">Class 11 (NEB Mat. 101 &bull; Foundations)</option>
                            <option value="Class 10">Class 10 (SEE Foundation &bull; Secondary)</option>
                            <option value="After 12">Entrance (After 12 IOE Pulchowk / CEE / KU)</option>
                        </select>
                    </div>

                    <div class="modal-field">
                        <label for="signupEmail">Email Address</label>
                        <input type="email" id="signupEmail" class="modal-input" placeholder="student@example.com" required>
                    </div>

                    <button type="submit" class="btn-submit-action" id="btnSendOtpSubmit">
                        <i class="fa-solid fa-paper-plane" style="margin-right:6px;"></i> Send 6-Digit Verification Code
                    </button>

                    <div style="text-align:center; margin-top:14px; font-size:0.82rem;">
                        <button type="button" class="btn-link-action" onclick="switchAuthTab('signin')">Already have an ID? Sign In</button>
                    </div>
                </form>
            </div>

            <!-- STEP 2: ENTER & VERIFY 6-DIGIT OTP -->
            <div id="otpStep2Container" class="auth-pane" style="display:none;">
                <div class="modal-head-tag" style="color:var(--accent-navy);">Step 2 &bull; Enter One-Time Password</div>
                <h3 class="modal-title">Enter 6-Digit Code</h3>
                <p class="modal-sub">
                    We sent a 6-digit code to <strong id="otpTargetEmailBadge" style="color:var(--accent-navy);">your email</strong>. Enter it below to unlock your workspace:
                </p>

                <!-- Local Fallback OTP Alert Box -->
                <div class="local-otp-banner" id="otpLocalPreviewBanner" style="display:none;">
                    <div style="font-weight:700; margin-bottom:3px;"><i class="fa-solid fa-key"></i> Instant Verification Code:</div>
                    <div class="local-otp-code-highlight" id="otpPreviewCodeValue">894215</div>
                </div>

                <form onsubmit="handleVerifyEmailOtp(event)">
                    <div class="otp-boxes-grid" id="otpBoxesWrap">
                        <input type="text" maxlength="1" class="otp-digit-box" id="otpDigit0" inputmode="numeric" oninput="handleOtpBoxInput(0, this)" onkeydown="handleOtpBoxKeydown(0, event)" autofocus required>
                        <input type="text" maxlength="1" class="otp-digit-box" id="otpDigit1" inputmode="numeric" oninput="handleOtpBoxInput(1, this)" onkeydown="handleOtpBoxKeydown(1, event)" required>
                        <input type="text" maxlength="1" class="otp-digit-box" id="otpDigit2" inputmode="numeric" oninput="handleOtpBoxInput(2, this)" onkeydown="handleOtpBoxKeydown(2, event)" required>
                        <input type="text" maxlength="1" class="otp-digit-box" id="otpDigit3" inputmode="numeric" oninput="handleOtpBoxInput(3, this)" onkeydown="handleOtpBoxKeydown(3, event)" required>
                        <input type="text" maxlength="1" class="otp-digit-box" id="otpDigit4" inputmode="numeric" oninput="handleOtpBoxInput(4, this)" onkeydown="handleOtpBoxKeydown(4, event)" required>
                        <input type="text" maxlength="1" class="otp-digit-box" id="otpDigit5" inputmode="numeric" oninput="handleOtpBoxInput(5, this)" onkeydown="handleOtpBoxKeydown(5, event)" required>
                    </div>

                    <button type="submit" class="btn-submit-action" id="btnVerifyOtpSubmit">
                        <i class="fa-solid fa-unlock-keyhole" style="margin-right:6px;"></i> Verify &amp; Mount My Class Workspace
                    </button>

                    <div style="display:flex; justify-content:space-between; align-items:center; margin-top:14px; font-size:0.82rem;">
                        <button type="button" class="btn-resend-link" onclick="resendEmailOtpCode()">Didn’t receive code? Resend OTP</button>
                        <button type="button" class="btn-link-action" onclick="switchAuthTab('signup')">← Back</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- ==========================================================================
         RESTRICTED ACCESS ALERT MODAL (SINGLE-CLASS DEDICATED ARCHITECTURE)
         ========================================================================== -->
    <div class="modal-backdrop" id="restrictedAccessModal" role="dialog" aria-modal="true">
        <div class="modal-card" style="max-width:500px; padding:28px 24px; text-align:center;">
            <button class="btn-modal-dismiss" onclick="closeRestrictedAccessModal()"><i class="fa-solid fa-xmark"></i></button>
            <div style="width:56px; height:56px; border-radius:50%; background:#FEF3C7; color:#B45309; display:inline-flex; align-items:center; justify-content:center; font-size:1.6rem; margin-bottom:14px;">
                <i class="fa-solid fa-shield-halved"></i>
            </div>
            <h3 style="font-size:1.28rem; font-weight:700; color:var(--text-primary); margin-bottom:8px;">Exclusive Program Access</h3>
            <p id="restrictedAccessMessage" style="font-size:0.92rem; line-height:1.6; color:var(--text-secondary); margin-bottom:20px;">
                Your ID is registered exclusively for <strong>Grade XII Mathematics</strong>. To enroll in a different program, please register a new account.
            </p>
            <div style="display:flex; flex-direction:column; gap:10px;">
                <button type="button" class="btn btn-primary" onclick="handleSwitchAccountRegister()" style="padding:12px 18px; font-size:0.92rem; justify-content:center;">
                    <i class="fa-solid fa-user-plus" style="margin-right:6px;"></i> Register a New Account for this Class
                </button>
                <button type="button" class="btn btn-secondary" onclick="openMyClassWorkspace(); closeRestrictedAccessModal();" style="padding:10px 18px; font-size:0.88rem; justify-content:center;">
                    <i class="fa-solid fa-arrow-left" style="margin-right:6px;"></i> Return to My Registered Workspace
                </button>
            </div>
        </div>
    </div>

    <!-- Live Zoom Session Detail Modal -->
    <div class="modal-backdrop" id="calendarSessionModal" role="dialog" aria-modal="true">
        <div class="modal-card" style="max-width: 580px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px;">
                <span class="modal-head-tag" style="margin: 0;">Live Zoom Class Details</span>
                <button class="btn-modal-dismiss static" onclick="closeCalendarSessionModal()"><i class="fa-solid fa-xmark"></i></button>
            </div>
            <div id="calendarSessionModalBody"></div>
        </div>
    </div>

    <!-- PDF / Formula Sheet Viewer Modal -->
    <div class="modal-backdrop pdf-reader-modal" id="pdfViewerModal" role="dialog" aria-modal="true">
        <div class="modal-card pdf-reader-card" style="max-width: 780px;">
            <div class="pdf-reader-bar" style="display: flex; align-items: center; justify-content: space-between; padding-bottom: 12px; border-bottom: 1px solid var(--border-soft); margin-bottom: 14px;">
                <div style="display: flex; align-items: center; gap: 8px;">
                    <span class="badge-free" id="pdfModalBadge" style="font-size: 0.72rem; padding: 2px 8px; border-radius: 999px;">Verified Resource</span>
                    <h3 id="pdfModalTitle" style="font-size: 1.1rem; margin: 0; color: var(--text-primary);">Mathematical Notes</h3>
                </div>
                <button class="btn-modal-dismiss static" onclick="closePdfViewerModal()"><i class="fa-solid fa-xmark"></i></button>
            </div>
            <p id="pdfModalMeta" style="font-size: 0.8rem; color: var(--text-secondary); margin-bottom: 14px;"></p>
            <div id="pdfModalBody" class="pdf-embed-wrapper" style="max-height: 55vh; overflow-y: auto; margin-bottom: 16px;"></div>
            <div style="display: flex; justify-content: flex-end; gap: 10px; padding-top: 12px; border-top: 1px solid var(--border-soft);">
                <a href="#" id="pdfModalDownloadBtn" class="btn btn-secondary" style="font-size: 0.82rem; padding: 8px 14px; text-decoration: none;"><i class="fa-solid fa-download"></i> Download Note / Formula Sheet</a>
                <button class="btn btn-primary" onclick="closePdfViewerModal()" style="font-size: 0.82rem; padding: 8px 14px;">Close Preview</button>
            </div>
        </div>
    </div>

    <!-- Toast Notification Container -->
    <div id="toastContainer" class="toast-container"></div>
`;
    }
})();
