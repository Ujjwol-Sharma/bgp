/**
 * BPG Academy — Serverless OTP Verifier & Session Token Issuer (api/verify-otp.js)
 * Validates the 6-digit OTP using both in-memory store and stateless HMAC-SHA256 verification.
 */

const crypto = require('crypto');

const OTP_SECRET = process.env.OTP_SECRET || 'bpg-maths-academy-hmac-secret-2026';

if (!global.__BPG_OTP_STORE__) {
    global.__BPG_OTP_STORE__ = new Map();
}

function verifySignedOtpToken(email, otp, otpToken) {
    if (!otpToken) return { valid: false, reason: 'Missing verification token.' };
    try {
        const decoded = JSON.parse(Buffer.from(otpToken, 'base64url').toString('utf8'));
        if (!decoded || decoded.email !== email.toLowerCase().trim()) {
            return { valid: false, reason: 'Email mismatch for verification token.' };
        }
        if (Date.now() > Number(decoded.expiresAt)) {
            return { valid: false, reason: 'Verification code has expired. Please request a new OTP.' };
        }
        const expectedPayload = `${email.toLowerCase().trim()}|${String(otp).trim()}|${decoded.expiresAt}`;
        const expectedSig = crypto
            .createHmac('sha256', OTP_SECRET)
            .update(expectedPayload)
            .digest('hex');

        const expectedBuf = Buffer.from(expectedSig, 'hex');
        const actualBuf = Buffer.from(String(decoded.signature || ''), 'hex');
        if (expectedBuf.length === 0 || expectedBuf.length !== actualBuf.length) {
            return { valid: false, reason: 'Invalid 6-digit verification code.' };
        }
        const isMatch = crypto.timingSafeEqual(expectedBuf, actualBuf);
        return isMatch
            ? { valid: true }
            : { valid: false, reason: 'Invalid 6-digit verification code.' };
    } catch (e) {
        return { valid: false, reason: 'Invalid verification code or token format.' };
    }
}

function issueStudentSessionToken(email, name, grade) {
    const issuedAt = Date.now();
    const expiresAt = issuedAt + 30 * 24 * 60 * 60 * 1000; // 30 days
    const payload = { email, name, grade, verified: true, issuedAt, expiresAt };
    const sig = crypto
        .createHmac('sha256', OTP_SECRET)
        .update(JSON.stringify(payload))
        .digest('hex');
    return Buffer.from(JSON.stringify({ ...payload, sig })).toString('base64url');
}

module.exports = async function handler(req, res) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

    if (req.method === 'OPTIONS') {
        return res.status(200).end();
    }

    if (req.method !== 'POST') {
        return res.status(405).json({ ok: false, error: 'Method Not Allowed. Use POST.' });
    }

    try {
        const body = typeof req.body === 'string' ? JSON.parse(req.body || '{}') : (req.body || {});
        const email = String(body.email || '').trim().toLowerCase();
        const otp = String(body.otp || '').trim();
        const otpToken = String(body.otpToken || '').trim();
        const name = String(body.name || 'Student').trim();
        const grade = String(body.grade || 'Class 11').trim();

        if (!email || !/^\d{6}$/.test(otp)) {
            return res.status(400).json({
                ok: false,
                error: 'Please enter a valid 6-digit numeric OTP code.'
            });
        }

        // Check in-memory store first if present
        const memRecord = global.__BPG_OTP_STORE__.get(email);
        let verified = false;

        if (memRecord) {
            if (Date.now() > memRecord.expiresAt) {
                global.__BPG_OTP_STORE__.delete(email);
                return res.status(400).json({ ok: false, error: 'OTP has expired. Please request a new code.' });
            }
            if ((memRecord.attempts || 0) >= 5) {
                global.__BPG_OTP_STORE__.delete(email);
                return res.status(429).json({ ok: false, error: 'Too many incorrect OTP attempts. Please request a new code.' });
            }
            if (memRecord.otp === otp) {
                verified = true;
                global.__BPG_OTP_STORE__.delete(email);
            } else {
                memRecord.attempts = (memRecord.attempts || 0) + 1;
            }
        }

        // Stateless HMAC verification (works across Vercel serverless cold starts)
        if (!verified && otpToken) {
            const check = verifySignedOtpToken(email, otp, otpToken);
            if (!check.valid) {
                return res.status(401).json({ ok: false, error: check.reason });
            }
            verified = true;
        }

        if (!verified) {
            return res.status(401).json({
                ok: false,
                error: 'Incorrect 6-digit OTP code. Please check and try again.'
            });
        }

        const sessionToken = issueStudentSessionToken(email, name, grade);

        return res.status(200).json({
            ok: true,
            verified: true,
            sessionToken,
            user: {
                name,
                email,
                grade,
                verified: true,
                verifiedAt: new Date().toISOString()
            },
            message: 'Email verified! Unlocking BPG Academy Portal.'
        });
    } catch (err) {
        console.error('[BPG Verify OTP Error]:', err);
        return res.status(500).json({
            ok: false,
            error: 'Verification failed. Please try again.'
        });
    }
};
