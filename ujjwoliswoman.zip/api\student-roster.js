/**
 * BPG Academy — Student Roster & Permissions API (/api/student-roster)
 * Strict Single-Class Architecture:
 *   - Each student is registered for exactly ONE dedicated class.
 *   - All multi-class passes and tiered pricing have been removed.
 */

const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '..', 'data');
const ROSTER_PATH = path.join(DATA_DIR, 'student-roster.json');
const MASTER_PASSKEY = 'bpg2026';

function gradeToClassKey(grade) {
    if (!grade) return 'class-12';
    const g = String(grade).toLowerCase();
    if (g.includes('10')) return 'class-10';
    if (g.includes('11')) return 'class-11';
    if (g.includes('12')) return 'class-12';
    if (g.includes('entrance') || g.includes('after')) return 'after-12';
    return 'class-12';
}

function normalizeGradeName(grade) {
    if (!grade) return 'Class 12';
    const g = String(grade).toLowerCase();
    if (g.includes('10')) return 'Class 10';
    if (g.includes('11')) return 'Class 11';
    if (g.includes('12')) return 'Class 12';
    if (g.includes('entrance') || g.includes('after')) return 'After 12 Entrance';
    return 'Class 12';
}

function ensureRosterExists() {
    if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (!fs.existsSync(ROSTER_PATH)) {
        const initial = {
            lastUpdated: new Date().toISOString(),
            accounts: [
                { name: 'Creative Scholar', email: 'scholar@bpgacademy.edu.np', grade: 'Class 12', classKey: 'class-12', joinedAt: '2026-11-01' },
                { name: 'Rohan Sharma', email: 'rohan.sharma@gmail.com', grade: 'Class 11', classKey: 'class-11', joinedAt: '2026-11-03' },
                { name: 'Aayush KC', email: 'aayush.kc@gmail.com', grade: 'Class 10', classKey: 'class-10', joinedAt: '2026-11-04' },
                { name: 'Prabhat Paudel', email: 'prabhat.entrance@gmail.com', grade: 'After 12 Entrance', classKey: 'after-12', joinedAt: '2026-11-05' }
            ]
        };
        fs.writeFileSync(ROSTER_PATH, JSON.stringify(initial, null, 2), 'utf8');
    }
}

module.exports = function studentRosterHandler(req, res) {
    ensureRosterExists();

    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, x-admin-passkey, Authorization');

    if (req.method === 'OPTIONS') {
        res.statusCode = 204;
        res.end();
        return;
    }

    if (req.method === 'GET' || req.method === 'HEAD') {
        try {
            const raw = fs.readFileSync(ROSTER_PATH, 'utf8');
            const data = JSON.parse(raw);
            res.statusCode = 200;
            if (req.method === 'HEAD') {
                res.end();
                return;
            }
            res.end(JSON.stringify({
                success: true,
                data: data
            }));
        } catch (err) {
            console.error('[API /api/student-roster] Read error:', err);
            res.statusCode = 500;
            res.end(JSON.stringify({ success: false, error: err.message }));
        }
        return;
    }

    if (req.method === 'POST') {
        const payload = req.body || {};
        const passkey = req.headers['x-admin-passkey'] || payload.adminPasskey;

        try {
            let roster = JSON.parse(fs.readFileSync(ROSTER_PATH, 'utf8'));
            if (!Array.isArray(roster.accounts)) {
                roster.accounts = [];
            }

            // Action: UPDATE_CLASS / UPDATE_STUDENT_CLASS
            if (payload.action === 'UPDATE_CLASS' || payload.action === 'UPDATE_STUDENT_CLASS') {
                const targetEmail = (payload.email || payload.accountEmail || '').toLowerCase();
                const newGrade = normalizeGradeName(payload.grade || payload.newGrade);
                const classKey = gradeToClassKey(newGrade);

                const acc = roster.accounts.find(a => (a.email || '').toLowerCase() === targetEmail);
                if (acc) {
                    acc.grade = newGrade;
                    acc.classKey = classKey;
                }
            }
            // Action: DELETE_STUDENT
            else if (payload.action === 'DELETE_STUDENT') {
                const targetEmail = (payload.email || payload.accountEmail || '').toLowerCase();
                roster.accounts = roster.accounts.filter(a => (a.email || '').toLowerCase() !== targetEmail);
            }
            // Action: REGISTER_STUDENT or newAccount payload
            else if (payload.action === 'REGISTER_STUDENT' || payload.newAccount) {
                const student = payload.student || payload.newAccount || {};
                const email = (student.email || '').trim().toLowerCase();
                const name = (student.name || 'Student').trim();
                const grade = normalizeGradeName(student.grade || student.classKey);
                const classKey = gradeToClassKey(grade);

                if (email) {
                    const existingIdx = roster.accounts.findIndex(a => (a.email || '').toLowerCase() === email);
                    if (existingIdx >= 0) {
                        roster.accounts[existingIdx].name = name;
                        roster.accounts[existingIdx].grade = grade;
                        roster.accounts[existingIdx].classKey = classKey;
                    } else {
                        roster.accounts.unshift({
                            name,
                            email,
                            grade,
                            classKey,
                            joinedAt: new Date().toISOString().split('T')[0]
                        });
                    }
                }
            }

            roster.lastUpdated = new Date().toISOString();

            const tmp = ROSTER_PATH + '.tmp.' + Date.now();
            fs.writeFileSync(tmp, JSON.stringify(roster, null, 2), 'utf8');
            fs.renameSync(tmp, ROSTER_PATH);

            res.statusCode = 200;
            res.end(JSON.stringify({
                success: true,
                message: 'Student roster updated successfully',
                data: roster
            }));
        } catch (err) {
            console.error('[API /api/student-roster] Write error:', err);
            res.statusCode = 500;
            res.end(JSON.stringify({ success: false, error: err.message }));
        }
        return;
    }

    res.statusCode = 405;
    res.end(JSON.stringify({ success: false, error: 'Method not allowed' }));
};
